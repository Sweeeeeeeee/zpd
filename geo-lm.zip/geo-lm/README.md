# geo_lm — a small transformer for auxiliary constructions in geometry

`geo_lm` is a small decoder-only transformer, written from scratch in PyTorch, that
proposes **auxiliary constructions** for geometry problems written in Newclid /
AlphaGeometry syntax. It ships with a tokenizer for that syntax, greedy decoding,
deterministic beam search, and checkpoint save/load. No pretrained weights are used.
Everything runs on CPU; a modest GPU is used automatically when present.

It is step 3 of a larger project: Newclid's DDAR engine does the deduction, and
this model suggests a new point when DDAR gets stuck.

## Install

```bash
git clone <your-repo-url> && cd <repo>
python -m venv .venv && source .venv/bin/activate
# CPU-only PyTorch (much smaller download):
pip install torch --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
```

Requires Python ≥ 3.9 and PyTorch ≥ 2.0 (1.13 works, using a slower attention path).

## Check it works

```bash
python -m pytest -q                      # 24 tests, a few seconds on CPU
python scripts/smoke_transformer.py      # trains a tiny model for ~10 s, must print SMOKE TEST PASSED
```

## Repository layout

| Path | Contents |
|---|---|
| `geo_lm/config.py` | `ModelConfig`: model hyperparameters, read from JSON |
| `geo_lm/tokenizer.py` | `GeoTokenizer`: syntax-aware tokenizer and the sequence format |
| `geo_lm/model.py` | `GeoTransformer`: the model, `generate()`, `beam_search()` |
| `geo_lm/checkpoint.py` | `save_checkpoint()` / `load_checkpoint()` |
| `configs/` | `model_tiny.json` (~0.14M params), `model_small.json` (~11M params) |
| `scripts/smoke_transformer.py` | End-to-end check: build, train, decode, save, reload |
| `tests/` | Unit tests |

## Specification

### Sequence format

Every training example and every inference prompt uses one format:

```
<bos> PROBLEM <aux> AUX_CONSTRUCTION <eos>
```

* **PROBLEM** is a Newclid problem, for example
  `a b c = triangle a b c; d = midpoint d b c ? para d e a b`.
* **AUX_CONSTRUCTION** is one or more construction clauses, for example
  `e = on_line e a d, on_line e b c`.
* At inference the model is given `<bos> PROBLEM <aux>` and generates until `<eos>`.

### Tokenizer rules

* `;` `,` `=` `?` are always separate tokens.
* Other words are split into identifiers (`a`, `a1`, `on_tline`), single digits and
  single symbols. Pieces after the first in a word get a `##` prefix:
  `1pi/3` → `1 ##pi ##/ ##3`.
* Special tokens, always ids 0–4: `<pad> <unk> <bos> <eos> <aux>`.
* Decoding gives canonical spacing: `decode(encode(x)) == normalize(x)`.
  Canonical form is `a b c = triangle a b c; d = midpoint d a b ? cong d a d b`.
* The vocabulary is built from your corpus, ordered by frequency and then
  alphabetically, so the same corpus always gives the same vocabulary. Digits, `a`–`z`, `pi` and `/` are
  always included.

### Model config (`ModelConfig`)

| Field | Default | Meaning |
|---|---|---|
| `vocab_size` | 1024 | Output size; must be ≥ `len(tokenizer)` |
| `context_length` | 256 | Maximum tokens (prompt plus output) |
| `n_layer` | 4 | Transformer blocks |
| `n_head` | 4 | Attention heads; must divide `n_embd` |
| `n_embd` | 256 | Embedding width |
| `dropout` | 0.1 | In `[0, 1)`; 0 for tiny or overfitting runs |
| `bias` | false | Biases in Linear and LayerNorm layers |
| `tie_weights` | true | Share input embedding and output projection |

The JSON file can contain only these fields, or put them under a `"model"` key
inside a larger project config. Keys starting with `_` are treated as comments.
Unknown keys or invalid values raise `ValueError`.

Architecture: learned positional embeddings, pre-LayerNorm blocks, causal
multi-head self-attention, a GELU MLP with 4× width, and GPT-2-style initialisation.

### Public API

```python
from geo_lm import (ModelConfig, GeoTokenizer, create_model, pick_device,
                    save_checkpoint, load_checkpoint, normalize)
```

| Call | Returns / does |
|---|---|
| `ModelConfig.from_json(path)` / `.to_json(path)` | Load or save hyperparameters |
| `GeoTokenizer.build(texts, min_freq=1, max_size=None)` | Build a vocabulary from strings |
| `tok.encode(text)` / `tok.decode(ids)` | Text ↔ token ids |
| `tok.encode_prompt(problem)` | Ids for `<bos> problem <aux>` |
| `tok.encode_example(problem, aux)` | `(ids, start)`; `start` is where the construction begins (use it to mask the loss) |
| `tok.unknown_tokens(text)` | Tokens not in the vocabulary (for checking data) |
| `tok.save(path)` / `GeoTokenizer.load(path)` | Tokenizer as JSON |
| `create_model(cfg, tok)` | Randomly initialised `GeoTransformer`; checks the vocabulary fits |
| `model(idx, targets=None, ignore_index=-100)` | `(logits, loss)`; set targets to -100 at positions to ignore |
| `model.generate(idx, max_new_tokens, temperature=0.0, top_k=None, eos_id=None)` | Prompt plus generated ids; `temperature=0` is greedy and deterministic |
| `model.beam_search(prompt, beam_size, max_new_tokens, eos_id, length_penalty=1.0)` | List of `Hypothesis(tokens, logprob, score, finished)`, best first |
| `model.num_parameters()` | Parameter count |
| `save_checkpoint(path, model, tok, optimizer=None, step=None, extra=None)` | One `.pt` file, written atomically |
| `load_checkpoint(path, map_location="cpu")` | `(model, tokenizer, raw_dict)`; `raw_dict` holds `step`, `extra`, `optimizer_state` |
| `pick_device("auto")` | CUDA, then MPS, then CPU |

## Usage

### Train a model on your own pairs (minimal loop)

```python
import torch
from geo_lm import ModelConfig, GeoTokenizer, create_model, save_checkpoint

pairs = [("a b c = triangle a b c; d = midpoint d b c ? perp a d b c", "e = foot e a b c")]
tok = GeoTokenizer.build(p + " " + a for p, a in pairs)
model = create_model(ModelConfig.from_json("configs/model_tiny.json"), tok)

ids, start = tok.encode_example(*pairs[0])
x = torch.tensor([ids[:-1]])
y = torch.tensor([ids[1:]])
y[0, : start - 1] = -100                       # loss only on the construction
opt = torch.optim.AdamW(model.parameters(), lr=3e-3)
for _ in range(100):
    _, loss = model(x, y)
    opt.zero_grad(); loss.backward(); opt.step()

save_checkpoint("runs/demo.pt", model, tok, opt, step=100)
```

### Propose constructions for a problem

```python
import torch
from geo_lm import load_checkpoint

model, tok, _ = load_checkpoint("runs/demo.pt")
problem = "a b c = triangle a b c; d = midpoint d b c ? perp a d b c"

# single best guess (greedy)
prompt = torch.tensor(tok.encode_prompt(problem))
out = model.generate(prompt, max_new_tokens=40, eos_id=tok.eos_id)
print(tok.decode(out[0, len(prompt):]))

# several ranked candidates, used as the branching in the proof search
for h in model.beam_search(tok.encode_prompt(problem), beam_size=4,
                           max_new_tokens=40, eos_id=tok.eos_id):
    print(f"{h.score:.3f}", tok.decode(h.tokens))
```

### Choosing a model size

| Config | Params | Where it runs |
|---|---|---|
| `model_tiny.json` | ~0.14M | CPU; smoke tests and debugging |
| `model_small.json` | ~11M | 4–8 GB GPU; CPU works but is slow |

Set `context_length` to cover your longest `<bos> problem <aux> construction <eos>`.
Longer prompts are cut from the front during generation, so the start of the problem is lost.

## Limitations

* No KV cache: each generation step re-runs the whole sequence. This is fine for
  short constructions; add a cache first if beam search becomes slow.
* `generate` expects all rows in a batch to have the same length (no padding).
  Use one problem at a time with beam search.
* Point names are ordinary tokens. Renaming points to a fixed order when you
  generate data improves generalisation.

## Roadmap (rest of the project)

1. Newclid / DDAR setup  2. Rule toggling  **3. Transformer (this package)**
4. Data generation  5. Training script  6. Toolbox and pipeline  7. `solve()`
8. Problem translation guide  9. Docs and tests
